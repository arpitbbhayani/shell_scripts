SCE Assignment 3 
README

Instructions:

*)Read the assignment doc carefully.

*)Folder Helpers contains files relevant to questions 12 and 14

#)Once you are done with your solutions, read UploadFormat.txt to understand the upload format.

#)You can validate your submission before uploading using validator.sh
Its example use is shown in file UploadFormat.txt

Enjoy!


